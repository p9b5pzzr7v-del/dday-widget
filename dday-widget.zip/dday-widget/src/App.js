import { useState, useEffect } from "react";

const TOKEN = process.env.REACT_APP_NOTION_TOKEN;
const DB_ID = process.env.REACT_APP_NOTION_DB_ID;

function getDday(dateStr) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(dateStr);
  target.setHours(0, 0, 0, 0);
  return Math.ceil((target - today) / (1000 * 60 * 60 * 24));
}
function formatDday(diff) {
  if (diff === 0) return "D-Day";
  return diff > 0 ? `D-${diff}` : `D+${Math.abs(diff)}`;
}

function EventCard({ event, index }) {
  const diff = getDday(event.date);
  const cls = diff < 0 ? "past" : diff === 0 ? "today" : "future";
  return (
    <div style={{ animationDelay: `${index * 0.08}s` }} className="card">
      <div className="card-left">
        <span className="emoji">{event.emoji || "📅"}</span>
        <div>
          <div className="event-name">{event.name}</div>
          <div className="event-date">{event.date}</div>
        </div>
      </div>
      <div className={`badge ${cls}`}>{formatDday(diff)}</div>
    </div>
  );
}

const NOTION_TOOL = {
  name: "fetch_notion_db",
  description: "Fetch all pages from a Notion database and return them as raw JSON.",
  input_schema: {
    type: "object",
    properties: {
      database_id: { type: "string" },
      token: { type: "string" },
    },
    required: ["database_id", "token"],
  },
};

async function loadNotionEvents() {
  const messages = [{
    role: "user",
    content: `Use the fetch_notion_db tool with database_id="${DB_ID}" and token="${TOKEN}".
Then parse the results and return ONLY a JSON array like:
[{"name":"...","date":"YYYY-MM-DD","emoji":"..."}]
Rules:
- name = title property value
- date = date property start value (skip pages without date)
- emoji = page icon.emoji if exists, else "📅"
Return ONLY the raw JSON array. No explanation, no markdown.`,
  }];

  let res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 4000,
      tools: [NOTION_TOOL],
      messages,
    }),
  });
  let data = await res.json();
  if (data.error) throw new Error(data.error.message);

  if (data.stop_reason === "tool_use") {
    const toolBlock = data.content.find(b => b.type === "tool_use");

    const notionRes = await fetch(
      `https://api.notion.com/v1/databases/${toolBlock.input.database_id}/query`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${toolBlock.input.token}`,
          "Notion-Version": "2022-06-28",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ sorts: [{ property: "Date", direction: "ascending" }] }),
      }
    );

    if (!notionRes.ok) {
      const err = await notionRes.json().catch(() => ({}));
      throw new Error(`Notion API 오류 ${notionRes.status}: ${err.message || notionRes.statusText}`);
    }

    const notionData = await notionRes.json();

    messages.push({ role: "assistant", content: data.content });
    messages.push({
      role: "user",
      content: [{
        type: "tool_result",
        tool_use_id: toolBlock.id,
        content: JSON.stringify(notionData),
      }],
    });

    res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 2000,
        tools: [NOTION_TOOL],
        messages,
      }),
    });
    data = await res.json();
    if (data.error) throw new Error(data.error.message);
  }

  const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("");
  const start = text.indexOf("[");
  const end = text.lastIndexOf("]");
  if (start === -1 || end === -1) throw new Error("JSON 배열 없음: " + text.slice(0, 200));
  return JSON.parse(text.slice(start, end + 1)).filter(e => e.date);
}

export default function App() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    loadNotionEvents()
      .then(parsed => {
        if (!parsed.length) throw new Error("이벤트가 없어요.");
        setEvents(parsed);
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const sorted = [...events].sort((a, b) => {
    const da = getDday(a.date), db = getDday(b.date);
    if (da >= 0 && db >= 0) return da - db;
    if (da < 0 && db < 0) return db - da;
    return da >= 0 ? -1 : 1;
  });

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Syne:wght@400;600;700;800&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        body{background:#eceae5;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif}
        @keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
        @keyframes spin{to{transform:rotate(360deg)}}
        .widget{width:360px;background:#faf8f5;border-radius:28px;padding:30px 26px 26px;box-shadow:0 12px 56px rgba(0,0,0,.12),0 2px 8px rgba(0,0,0,.06)}
        .header{display:flex;align-items:center;justify-content:space-between;margin-bottom:22px}
        .title{font-family:'DM Serif Display',serif;font-size:22px;color:#18182a;letter-spacing:-.4px}
        .dot{width:7px;height:7px;border-radius:50%;background:#4caf78;animation:pulse 2s infinite}
        .cards{display:flex;flex-direction:column;gap:10px}
        .card{background:#fff;border-radius:16px;padding:14px 16px;display:flex;align-items:center;justify-content:space-between;border:1px solid #ece9e3;animation:fadeUp .4s ease forwards;opacity:0;transition:transform .18s,box-shadow .18s;cursor:default}
        .card:hover{transform:translateY(-2px);box-shadow:0 6px 24px rgba(0,0,0,.08)}
        .card-left{display:flex;align-items:center;gap:12px}
        .emoji{font-size:26px;line-height:1;min-width:30px;text-align:center}
        .event-name{font-size:13px;font-weight:700;color:#18182a}
        .event-date{font-size:11px;color:#b0a89e;margin-top:2px}
        .badge{font-family:'DM Serif Display',serif;font-size:20px;letter-spacing:-.8px;flex-shrink:0}
        .badge.future{color:#6c63ff}.badge.today{color:#e84393}.badge.past{color:#ccc7bf}
        .loading{display:flex;flex-direction:column;align-items:center;gap:12px;padding:30px 0;color:#b0a89e;font-size:13px}
        .spinner{width:24px;height:24px;border:2px solid #ece9e3;border-top-color:#6c63ff;border-radius:50%;animation:spin .8s linear infinite}
        .err{font-size:12px;color:#e84393;padding:16px 0;text-align:center;line-height:1.6}
      `}</style>
      <div className="widget">
        <div className="header">
          <span className="title">D-Day</span>
          <span className="dot" />
        </div>
        {loading && (
          <div className="loading">
            <div className="spinner" />
            불러오는 중...
          </div>
        )}
        {error && <div className="err">⚠️ {error}</div>}
        {!loading && !error && (
          <div className="cards">
            {sorted.map((ev, i) => <EventCard key={i} event={ev} index={i} />)}
          </div>
        )}
      </div>
    </>
  );
}
